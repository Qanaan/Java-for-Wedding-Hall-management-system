/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hall.booking.management.system;

/**
 *
 * @author hp
 */


import java.io.*;

public class SalesFileCreator {

    public static void createSalesFile() {
        String fileName = "sales.txt";
        File file = new File(fileName);

        // Check if file already exists to avoid overwriting it
        if (!file.exists()) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                // Write sample sales data to the file in the correct format
                writer.write("1;John Doe;Hall A;2024-09-01;500.00\n");
                writer.write("2;Jane Smith;Hall B;2024-09-03;750.00\n");
                writer.write("3;Mark Johnson;Hall C;2024-09-05;300.00\n");
                writer.write("4;Emily Davis;Hall A;2024-09-08;450.00\n");
                writer.write("5;Michael Brown;Hall B;2024-09-10;600.00\n");
                writer.write("6;Sarah Wilson;Hall C;2024-09-12;350.00\n");
                writer.write("7;David Taylor;Hall A;2024-09-15;520.00\n");
                writer.write("8;Laura Harris;Hall B;2024-09-18;720.00\n");
                writer.write("9;Paul Walker;Hall C;2024-09-20;400.00\n");
                writer.write("10;Sophia Moore;Hall A;2024-09-22;550.00\n");

                System.out.println("sales.txt file created successfully.");
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("sales.txt file already exists.");
        }
    }

    public static void main(String[] args) {
        createSalesFile();  // Call method to create sales.txt file
    }
}


