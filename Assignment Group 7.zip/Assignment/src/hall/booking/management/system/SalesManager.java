/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hall.booking.management.system;

/**
 *
 * @author hp
 */


import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class SalesManager {
    private static final String FILE_NAME = "sales.txt";
    private List<Sale> sales;

    public SalesManager() {
        sales = loadSales();
    }

    // Load sales from the file
    private List<Sale> loadSales() {
        List<Sale> salesList = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(";");
                if (data.length == 5) {
                    int id = Integer.parseInt(data[0]);
                    String customerName = data[1];
                    String hall = data[2];
                    LocalDate date = LocalDate.parse(data[3], DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                    double amount = Double.parseDouble(data[4]);
                    salesList.add(new Sale(id, customerName, hall, date, amount));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return salesList;
    }

    // Method to calculate the total sales amount
    public double getTotalSales() {
        return sales.stream().mapToDouble(Sale::getAmount).sum();
    }

    // Filter sales for the last week
    public double filterSalesByWeek() {
        LocalDate today = LocalDate.now();
        LocalDate weekAgo = today.minusDays(7);
        return sales.stream()
                .filter(sale -> sale.getDate().isAfter(weekAgo) && sale.getDate().isBefore(today.plusDays(1)))
                .mapToDouble(Sale::getAmount)
                .sum();
    }

    // Filter sales for the current month (current month and year)
    public double filterSalesByMonth() {
        LocalDate today = LocalDate.now();
        int currentMonth = today.getMonthValue();
        int currentYear = today.getYear();

        return sales.stream()
                .filter(sale -> sale.getDate().getMonthValue() == currentMonth && sale.getDate().getYear() == currentYear)
                .mapToDouble(Sale::getAmount)
                .sum();
    }

    // Filter sales for the current year (all months in the current year)
    public double filterSalesByYear() {
        LocalDate today = LocalDate.now();
        int currentYear = today.getYear();

        return sales.stream()
                .filter(sale -> sale.getDate().getYear() == currentYear)
                .mapToDouble(Sale::getAmount)
                .sum();
    }
}





