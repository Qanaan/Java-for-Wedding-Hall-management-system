/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hall.booking.management.system;

/**
 *
 * @author hp
 */



import java.io.*;

public class IssueFileCreator {

    public static void main(String[] args) {
        createIssuesFile();
    }

    public static void createIssuesFile() {
        File file = new File("issues.txt");
        
        // Check if the file exists, if not, create it
        if (!file.exists()) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                // Add sample issues
                writer.write("001;Air conditioning not working;Open\n");
                writer.write("002;Lighting issues in Hall A;Open\n");
                writer.write("003;Projector malfunctioning;In Progress\n");
                System.out.println("issues.txt file created successfully!");
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("issues.txt already exists.");
        }
    }
}

