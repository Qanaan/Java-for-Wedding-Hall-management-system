/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hall.booking.management.system;

/**
 *
 * @author hp
 */



import hall.booking.management.system.MaintenanceManager;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class MaintenanceGUI extends JFrame {
    private MaintenanceManager manager;
    private List<Issue> issues;

    public MaintenanceGUI() {
        setTitle("Maintenance Manager");
        setSize(400, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        manager = new MaintenanceManager();
        issues = manager.loadIssues();

        // If issues.txt is missing or empty, handle it gracefully
        if (issues.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No issues found or issues.txt is missing!", "Error", JOptionPane.ERROR_MESSAGE);
        }

        // Display the issues in a text area
        JTextArea textArea = new JTextArea();
        for (Issue issue : issues) {
            textArea.append(issue.toString() + "\n");
        }

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(1, 3));

        // Button to update an issue
        JButton updateButton = new JButton("Update Issue");
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String issueId = JOptionPane.showInputDialog("Enter Issue ID to update:");
                Issue issue = manager.findIssueById(issues, issueId);
                if (issue != null) {
                    String newStatus = JOptionPane.showInputDialog("Enter new status (In Progress, Done, Closed, Cancelled):");
                    issue.setStatus(newStatus);
                    manager.saveIssues(issues);  // Save changes to file
                    refreshTextArea(textArea);  // Refresh display
                } else {
                    JOptionPane.showMessageDialog(null, "Issue not found!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Button to add a new issue
        JButton addButton = new JButton("Add Issue");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String issueId = JOptionPane.showInputDialog("Enter new Issue ID:");
                String description = JOptionPane.showInputDialog("Enter Issue Description:");
                String reportedBy = JOptionPane.showInputDialog("Enter Reported By:");
                String status = JOptionPane.showInputDialog("Enter status (Open, In Progress, Done, Closed):");

                // Create a new issue and add to the list
                Issue newIssue = new Issue(issueId, description, reportedBy, status);
                issues.add(newIssue);
                manager.saveIssues(issues);  // Save new issue to file
                refreshTextArea(textArea);  // Refresh display
            }
        });

        // Button to remove an issue
        JButton removeButton = new JButton("Remove Issue");
        removeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String issueId = JOptionPane.showInputDialog("Enter Issue ID to remove:");
                Issue issue = manager.findIssueById(issues, issueId);
                if (issue != null) {
                    issues.remove(issue);  // Remove issue from list
                    manager.saveIssues(issues);  // Save changes to file
                    refreshTextArea(textArea);  // Refresh display
                } else {
                    JOptionPane.showMessageDialog(null, "Issue not found!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        buttonPanel.add(updateButton);
        buttonPanel.add(addButton);
        buttonPanel.add(removeButton);

        add(new JScrollPane(textArea), BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    // Method to refresh the JTextArea with updated issue data
    private void refreshTextArea(JTextArea textArea) {
        textArea.setText("");
        for (Issue issue : issues) {
            textArea.append(issue.toString() + "\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MaintenanceGUI gui = new MaintenanceGUI();
            gui.setVisible(true);
        });
    }
}



