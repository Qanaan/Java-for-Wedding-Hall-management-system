/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hall.booking.management.system;

/**
 *
 * @author abood
 */



import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class FeedbackViewerGUI extends JFrame {
    private JTextArea feedbackTextArea;

    public FeedbackViewerGUI() {
        setTitle("Customer Feedback Viewer");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        feedbackTextArea = new JTextArea();
        feedbackTextArea.setEditable(false);  // Make the text area read-only

        JScrollPane scrollPane = new JScrollPane(feedbackTextArea);
        add(scrollPane, BorderLayout.CENTER);

        // Load feedback from file
        loadFeedback();

        setVisible(true);
    }

    // Method to load feedback from the file
    private void loadFeedback() {
        String fileName = "feedback.txt";
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            StringBuilder feedbackBuilder = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")) {
                    feedbackBuilder.append("\n");  // Add a new line between feedback entries
                } else {
                    feedbackBuilder.append(line).append("\n");
                }
            }
            feedbackTextArea.setText(feedbackBuilder.toString());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading feedback from file.", "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new FeedbackViewerGUI());
    }
}
