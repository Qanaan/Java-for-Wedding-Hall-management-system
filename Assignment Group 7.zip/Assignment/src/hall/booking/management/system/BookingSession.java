/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hall.booking.management.system;

/**
 *
 * @author abood
 */
public class BookingSession {
     // Single instance of BookingSession
    // Single instance of BookingSession
    private static BookingSession instance;

    // User Details
    private String customerName;
    private String customerEmail;

    // Booking Details
    private String hallName;
    private String capacity;
    private String date;
    private String startTime;
    private String endTime;
    private String price;

    // Private constructor to prevent direct instantiation
    private BookingSession() {}

    // Get the single instance of BookingSession
    public static BookingSession getInstance() {
        if (instance == null) {
            instance = new BookingSession();
        }
        return instance;
    }

    // Method to set user details
    public void setUserDetails(String customerName, String customerEmail) {
        this.customerName = customerName;
        this.customerEmail = customerEmail;
    }

    // Method to set booking details
    public void setBookingDetails(String hallName, String capacity, String date, String startTime, String endTime, String price) {
        this.hallName = hallName;
        this.capacity = capacity;
        this.date = date;
        this.startTime = startTime;
        this.endTime = endTime;
        this.price = price;
    }

    // Methods to retrieve user details
    public String getCustomerName() {
        return customerName;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    // Methods to retrieve booking details
    public String getHallName() {
        return hallName;
    }

    public String getCapacity() {
        return capacity;
    }

    public String getDate() {
        return date;
    }

    public String getStartTime() {
        return startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public String getPrice() {
        return price;
    }    
}
