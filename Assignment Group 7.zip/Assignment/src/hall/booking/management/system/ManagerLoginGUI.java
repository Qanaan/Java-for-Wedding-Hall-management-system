/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hall.booking.management.system;

/**
 *
 * @author hp
 */



import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ManagerLoginGUI extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;

    public ManagerLoginGUI() {
        setTitle("Manager Login");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Create login form
        JPanel panel = new JPanel(new GridLayout(3, 2));

        // Username
        panel.add(new JLabel("Username:"));
        usernameField = new JTextField();
        panel.add(usernameField);

        // Password
        panel.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        panel.add(passwordField);

        // Login button
        JButton loginButton = new JButton("Login");
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());

                if (authenticate(username, password)) {
                    // Redirect to Manager Home Page
                    new ManagerHomePage();  // Opens the manager's dashboard
                    dispose();  // Close login window
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid credentials or not a Manager!", "Login Failed", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        panel.add(loginButton);

        add(panel);
        setVisible(true);
    }

    // Method to authenticate by reading from user.txt
    private boolean authenticate(String username, String password) {
        try (BufferedReader reader = new BufferedReader(new FileReader("user1.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(";");
                String role = parts[1];
                String fileUsername = parts[2];
                String filePassword = parts[3];

                // Only allow login if the role is "Manager"
                if (role.equals("Manager") && username.equals(fileUsername) && password.equals(filePassword)) {
                    return true;  // Credentials matched
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;  // No match found or not a Manager
    }

    public static void main(String[] args) {
        new ManagerLoginGUI();
    }
}


