/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hall.booking.management.system;

/**
 *
 * @author hp
 */

import java.time.LocalDate;

public class Sale {
    private int id;
    private String customerName;
    private String hall;
    private LocalDate date;
    private double amount;

    public Sale(int id, String customerName, String hall, LocalDate date, double amount) {
        this.id = id;
        this.customerName = customerName;
        this.hall = hall;
        this.date = date;
        this.amount = amount;
    }

    public int getId() {
        return id;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getHall() {
        return hall;
    }

    public LocalDate getDate() {
        return date;
    }

    public double getAmount() {
        return amount;
    }

    @Override
    public String toString() {
        return id + ";" + customerName + ";" + hall + ";" + date + ";" + amount;
    }
}



