/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hall.booking.management.system;

/**
 *
 * @author hp
 */


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class UserFileCreator {

    public static void createUserFile() {
        String fileName = "user.txt";
        File file = new File(fileName);

        // Check if file already exists to avoid overwriting it
        if (!file.exists()) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                // Write sample user data to the file
                writer.write("1;Scheduler;johnDoe;password123;John Doe;johndoe@example.com\n");
                writer.write("2;Customer;janeDoe;pass456;Jane Doe;janedoe@example.com\n");
                writer.write("3;Manager;manager1;adminpass;Manager One;manager1@example.com\n");

                System.out.println("user.txt file created successfully.");
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("user.txt file already exists.");
        }
    }

    public static void main(String[] args) {
        createUserFile();  // Call method to create user.txt file
    }
}

