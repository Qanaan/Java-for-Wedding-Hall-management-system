/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hall.booking.management.system;

/**
 *
 * @author hp
 */



import hall.booking.management.system.SalesManager;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SalesDashboardGUI {
    private SalesManager salesManager;

    public SalesDashboardGUI() {
        salesManager = new SalesManager();
        createGUI();
    }

    // Create the Sales Dashboard GUI
    private void createGUI() {
        JFrame frame = new JFrame("Sales Dashboard");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 200);
        frame.setLayout(new GridLayout(3, 1, 10, 10));

        JLabel filterLabel = new JLabel("Filter sales by:");
        String[] filterOptions = {"All", "Weekly", "Monthly", "Yearly"};
        JComboBox<String> filterComboBox = new JComboBox<>(filterOptions);
        JLabel resultLabel = new JLabel(String.format("Total Sales: RM %.2f", salesManager.getTotalSales())); // Display all sales by default

        // Add components to the frame
        frame.add(filterLabel);
        frame.add(filterComboBox);
        frame.add(resultLabel);

        // Add ActionListener to the combo box
        filterComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedFilter = (String) filterComboBox.getSelectedItem();
                double totalSales = 0.0;

                // Filter sales based on the selected option
                switch (selectedFilter) {
                    case "Weekly":
                        totalSales = salesManager.filterSalesByWeek();
                        break;
                    case "Monthly":
                        totalSales = salesManager.filterSalesByMonth();
                        break;
                    case "Yearly":
                        totalSales = salesManager.filterSalesByYear();
                        break;
                    case "All":
                        totalSales = salesManager.getTotalSales(); // Show all sales if "All" is selected
                        break;
                }

                // Update the result label to show the filtered sales
                resultLabel.setText(String.format("Total Sales: RM %.2f", totalSales));
            }
        });

        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new SalesDashboardGUI();
            }
        });
    }

    void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}



