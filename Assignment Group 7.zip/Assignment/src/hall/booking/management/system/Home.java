package hall.booking.management.system;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Home extends javax.swing.JFrame {
    
    private static final String FILE_PATH = "C:/Users/abood/OneDrive - Asia Pacific University/Documents/NetBeansProjects/Assignment/ViewHall.txt";
    private DefaultTableModel model;
    private JTable table;
    
                                                                               
   
    public Home() {
        initComponents();
        ensureFileExists(); // Ensure the file exists
        loadData();
        initialize();
        
        
    }
    
    
    
    
//  C:/Users/Jason M/OneDrive/Documents/NetBeansProjects/Scheduler/src/HallBookingManagementSystem
    
    
private void ensureFileExists() {
        File file = new File(FILE_PATH);
        
        // Create the file if it doesn't exist
        if (!file.exists()) {
            try {
                file.createNewFile(); // Create the file if it doesn't exist
                try (PrintWriter writer = new PrintWriter(new FileWriter(file, true))) {
                    writer.println("Hall Name,Capacity,Date,Starting Time,Ending Time,Hall Price"); // Example header
                }
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Failed to create file 'ViewHall.txt'!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

   

    
    
  private void initialize() {
    setTitle("Hall Management");
    setSize(1400, 611);
    setMinimumSize(new Dimension(400, 300));
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    loadData(); // Load data from file

    String[] columnNames = {
        "Hall Name", "Capacity", "Date", "Starting Time", "Ending Time", "Hall Price",
        "Maintenance Start Date", "Maintenance Start Time", "Maintenance End Date", "Maintenance End Time"
    };

    model = new DefaultTableModel(columnNames, 0);
    table = new JTable(model);

    // Add the table to a JScrollPane
    JScrollPane scrollPane = new JScrollPane(table);
    
    // Set the preferred size for horizontal scroll
    table.setPreferredScrollableViewportSize(new Dimension(800, 400));
    
    // Add the JScrollPane to the frame
    add(scrollPane, BorderLayout.CENTER);

    // Set column sizes
    setColumnSizes();
}

    @SuppressWarnings("unchecked")
  
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        HomePanel = new javax.swing.JPanel();
        HomepageLogo = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        delbutton = new javax.swing.JButton();
        maintenancebut = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        HallTable = new javax.swing.JTable();
        addbut = new javax.swing.JToggleButton();
        editbut = new javax.swing.JToggleButton();
        logoutbtn = new javax.swing.JButton();
        ViewFilbtn = new javax.swing.JToggleButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        HomePanel.setBackground(new java.awt.Color(204, 204, 204));
        HomePanel.setPreferredSize(new java.awt.Dimension(1400, 611));

        HomepageLogo.setBackground(new java.awt.Color(255, 153, 153));
        HomepageLogo.setPreferredSize(new java.awt.Dimension(350, 600));

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/Logo.png"))); // NOI18N
        jLabel6.setToolTipText("");

        jLabel7.setFont(new java.awt.Font("STZhongsong", 1, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(51, 51, 51));
        jLabel7.setText("HALL SYMPHONY");

        jLabel8.setFont(new java.awt.Font("STZhongsong", 1, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(51, 51, 51));
        jLabel8.setText("HALL MANAGEMENT");

        javax.swing.GroupLayout HomepageLogoLayout = new javax.swing.GroupLayout(HomepageLogo);
        HomepageLogo.setLayout(HomepageLogoLayout);
        HomepageLogoLayout.setHorizontalGroup(
            HomepageLogoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, HomepageLogoLayout.createSequentialGroup()
                .addGap(0, 40, Short.MAX_VALUE)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35))
            .addGroup(HomepageLogoLayout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addComponent(jLabel7)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(HomepageLogoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(16, 16, 16))
        );
        HomepageLogoLayout.setVerticalGroup(
            HomepageLogoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, HomepageLogoLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 419, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(85, Short.MAX_VALUE))
        );

        delbutton.setBackground(new java.awt.Color(255, 153, 153));
        delbutton.setFont(new java.awt.Font("STZhongsong", 1, 14)); // NOI18N
        delbutton.setForeground(new java.awt.Color(51, 51, 51));
        delbutton.setText("Delete Hall");
        delbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delbuttonActionPerformed(evt);
            }
        });

        maintenancebut.setBackground(new java.awt.Color(255, 153, 153));
        maintenancebut.setFont(new java.awt.Font("STZhongsong", 1, 14)); // NOI18N
        maintenancebut.setForeground(new java.awt.Color(51, 51, 51));
        maintenancebut.setText("Maintenance");
        maintenancebut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                maintenancebutActionPerformed(evt);
            }
        });

        HallTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"Auditorium One", 1000, "2024/1/21", "1:44am", "3:33am", 175.0, null, null, null}, // New columns for maintenance
                {"Banquet Hall One", 300, "2024/6/9", "8:00pm", "11:30pm", 1250.0, null, null, null},
                {"Meeting Room One", 30, "2024/7/8", "6:00pm", "7:01pm", 27.0, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Hall Name", "Capacity", "Date", "Starting Time", "Ending Time", "Hall Price", "Maintenance Start", "Maintenance End", "Remarks" // New column headers
            }
        ) {
            Class[] types = new Class[] {
                java.lang.String.class,   // Hall Name
                java.lang.Integer.class,  // Capacity
                java.lang.String.class,   // Date
                java.lang.String.class,   // Starting Time
                java.lang.String.class,   // Ending Time
                java.lang.Double.class,   // Hall Price
                java.lang.String.class,   // Maintenance Start (new)
                java.lang.String.class,   // Maintenance End (new)
                java.lang.String.class    // Remarks (new)
            };

            @Override
            public Class<?> getColumnClass(int columnIndex) {
                return types[columnIndex];
            }

        });
        HallTable.setPreferredSize(new java.awt.Dimension(610, 360));
        jScrollPane1.setViewportView(HallTable);

        addbut.setBackground(new java.awt.Color(255, 153, 153));
        addbut.setFont(new java.awt.Font("STZhongsong", 1, 14)); // NOI18N
        addbut.setForeground(new java.awt.Color(51, 51, 51));
        addbut.setText("Add Hall");
        addbut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addbutActionPerformed(evt);
            }
        });

        editbut.setBackground(new java.awt.Color(255, 153, 153));
        editbut.setFont(new java.awt.Font("STZhongsong", 1, 14)); // NOI18N
        editbut.setForeground(new java.awt.Color(51, 51, 51));
        editbut.setText("Edit Hall");
        editbut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editbutActionPerformed(evt);
            }
        });

        logoutbtn.setBackground(new java.awt.Color(255, 153, 153));
        logoutbtn.setFont(new java.awt.Font("STZhongsong", 1, 14)); // NOI18N
        logoutbtn.setForeground(new java.awt.Color(51, 51, 51));
        logoutbtn.setText("Logout");
        logoutbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutbtnActionPerformed(evt);
            }
        });

        ViewFilbtn.setBackground(new java.awt.Color(255, 153, 153));
        ViewFilbtn.setFont(new java.awt.Font("STZhongsong", 1, 14)); // NOI18N
        ViewFilbtn.setForeground(new java.awt.Color(51, 51, 51));
        ViewFilbtn.setText("View/Filter");
        ViewFilbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ViewFilbtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout HomePanelLayout = new javax.swing.GroupLayout(HomePanel);
        HomePanel.setLayout(HomePanelLayout);
        HomePanelLayout.setHorizontalGroup(
            HomePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(HomePanelLayout.createSequentialGroup()
                .addComponent(HomepageLogo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(HomePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(HomePanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1173, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, HomePanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(addbut, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(editbut, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(HomePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(ViewFilbtn, javax.swing.GroupLayout.DEFAULT_SIZE, 156, Short.MAX_VALUE)
                            .addComponent(delbutton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(34, 34, 34))
                    .addGroup(HomePanelLayout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(maintenancebut, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(logoutbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(38, 38, 38))))
        );
        HomePanelLayout.setVerticalGroup(
            HomePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(HomePanelLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(HomepageLogo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(HomePanelLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(HomePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(logoutbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(maintenancebut, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addGroup(HomePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(delbutton, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(addbut, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(editbut, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ViewFilbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(HomePanel, javax.swing.GroupLayout.DEFAULT_SIZE, 1535, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(HomePanel, javax.swing.GroupLayout.PREFERRED_SIZE, 600, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 86, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void delbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delbuttonActionPerformed
    // Get the selected row index
    int selectedRow = HallTable.getSelectedRow();

    // Check if a row is selected
    if (selectedRow != -1) {
        // Get the table model
        DefaultTableModel model = (DefaultTableModel) HallTable.getModel();

        // Remove the selected row from the model
        model.removeRow(selectedRow);

        // Gather updated data
        int rowCount = model.getRowCount();
        int columnCount = model.getColumnCount();
        Object[][] updatedData = new Object[rowCount][columnCount];
        for (int i = 0; i < rowCount; i++) {
            for (int j = 0; j < columnCount; j++) {
                updatedData[i][j] = model.getValueAt(i, j);
            }
        }

        // Save to file
        saveAllToFile(updatedData, FILE_PATH);

        // Show a confirmation message
        JOptionPane.showMessageDialog(this, "Selected hall has been deleted.");
    } else {
        JOptionPane.showMessageDialog(this, "Please select a hall to delete.");
    }
    }//GEN-LAST:event_delbuttonActionPerformed

    private void maintenancebutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_maintenancebutActionPerformed
    // Get the selected row index from the table
    int selectedRow = HallTable.getSelectedRow();

    if (selectedRow != -1) { // Check if a row is selected
        // Get the hall name from the selected row
        DefaultTableModel model = (DefaultTableModel) HallTable.getModel();
        String hallName = model.getValueAt(selectedRow, 0).toString();
        
        // Prompt for maintenance details using JOptionPane
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        // Fields for input
        JTextField maintenanceStartTimeField = new JTextField(10);
        JTextField maintenanceEndTimeField = new JTextField(10);
        JTextField remarksField = new JTextField(10); // Field for remarks

        panel.add(new JLabel("Maintenance Start Time (HH:MM):"));
        panel.add(maintenanceStartTimeField);
        panel.add(new JLabel("Maintenance End Time (HH:MM):"));
        panel.add(maintenanceEndTimeField);
        panel.add(new JLabel("Remarks (optional):"));
        panel.add(remarksField);

        int result = JOptionPane.showConfirmDialog(null, panel, "Schedule Maintenance for " + hallName, JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            // Get the input values
            String maintenanceStartTime = maintenanceStartTimeField.getText().trim();
            String maintenanceEndTime = maintenanceEndTimeField.getText().trim();
            String remarks = remarksField.getText().trim();

            // Validate input
            if (maintenanceStartTime.isEmpty() || maintenanceEndTime.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Maintenance Start Time and End Time must be filled in.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Load existing data
            List<String> lines = new ArrayList<>();
            try (BufferedReader br = new BufferedReader(new FileReader(FILE_PATH))) {
                String line;
                while ((line = br.readLine()) != null) {
                    lines.add(line);
                }
            } catch (IOException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error loading data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Update the relevant line
            for (int i = 1; i < lines.size(); i++) { // Skip the header
                String[] hallData = lines.get(i).split(",");

                // Ensure hallData has enough columns
                while (hallData.length < 9) { // Ensure there are enough columns for the maintenance fields
                    hallData = Arrays.copyOf(hallData, 9); // Extend the array
                    hallData[6] = ""; // Initialize Maintenance Start Time
                    hallData[7] = ""; // Initialize Maintenance End Time
                    hallData[8] = ""; // Initialize Remarks
                }

                if (hallData[0].equals(hallName)) {
                    hallData[6] = maintenanceStartTime; // Maintenance Start Time
                    hallData[7] = maintenanceEndTime;   // Maintenance End Time
                    hallData[8] = remarks;               // Remarks
                    lines.set(i, String.join(",", hallData)); // Update the line
                    break;
                }
            }

            // Save the updated data back to the file
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
                for (String line : lines) {
                    writer.write(line);
                    writer.newLine();
                }
            } catch (IOException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error saving maintenance data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }

            // Reload data to refresh the table
            loadData();

            // Show a confirmation message
            JOptionPane.showMessageDialog(this, "Maintenance scheduled successfully for " + hallName, "Maintenance Scheduled", JOptionPane.INFORMATION_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(this, "Please select a hall to schedule maintenance.", "No Selection", JOptionPane.WARNING_MESSAGE);
    }
    }//GEN-LAST:event_maintenancebutActionPerformed

    private void addbutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addbutActionPerformed
    // Prompt the user for input
    String hallName = JOptionPane.showInputDialog(this, "Enter Hall Name:");
    if (hallName == null || hallName.trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Hall Name cannot be empty.");
        return;
    }

    String capacityStr = JOptionPane.showInputDialog(this, "Enter Capacity:");
    if (capacityStr == null || capacityStr.trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Capacity cannot be empty.");
        return;
    }

    int capacity;
    try {
        capacity = Integer.parseInt(capacityStr);
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Capacity must be a valid number.");
        return;
    }

    String date = JOptionPane.showInputDialog(this, "Enter Date (yyyy/mm/dd):");
    if (date == null || date.trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Date cannot be empty.");
        return;
    }

    String startTime = JOptionPane.showInputDialog(this, "Enter Starting Time (e.g., 8:00pm):");
    if (startTime == null || startTime.trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Starting Time cannot be empty.");
        return;
    }

    String endTime = JOptionPane.showInputDialog(this, "Enter Ending Time (e.g., 10:00pm):");
    if (endTime == null || endTime.trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Ending Time cannot be empty.");
        return;
    }

    String priceStr = JOptionPane.showInputDialog(this, "Enter Hall Price:");
    if (priceStr == null || priceStr.trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Hall Price cannot be empty.");
        return;
    }

    double price;
    try {
        price = Double.parseDouble(priceStr);
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Hall Price must be a valid number.");
        return;
    }

    // Add new row to the table
    DefaultTableModel model = (DefaultTableModel) HallTable.getModel();
    Object[] newRow = {hallName, capacity, date, startTime, endTime, price};
    model.addRow(newRow);

    // Gather updated data
    int rowCount = model.getRowCount();
    int columnCount = model.getColumnCount();
    Object[][] updatedData = new Object[rowCount][columnCount];
    for (int i = 0; i < rowCount; i++) {
        for (int j = 0; j < columnCount; j++) {
            updatedData[i][j] = model.getValueAt(i, j);
        }
    }

    // Save to file
    saveAllToFile(updatedData, FILE_PATH);

    // Reload data to refresh the table
    loadData();
    }//GEN-LAST:event_addbutActionPerformed

    private void editbutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editbutActionPerformed
    // Get the selected row
    int selectedRow = HallTable.getSelectedRow();
    if (selectedRow != -1) {
        DefaultTableModel model = (DefaultTableModel) HallTable.getModel();

        // Read current values from the selected row
        String hallName = model.getValueAt(selectedRow, 0).toString();
        int capacity = Integer.parseInt(model.getValueAt(selectedRow, 1).toString());
        String date = model.getValueAt(selectedRow, 2).toString();
        String startingTime = model.getValueAt(selectedRow, 3).toString();
        String endingTime = model.getValueAt(selectedRow, 4).toString();
        double hallPrice = Double.parseDouble(model.getValueAt(selectedRow, 5).toString());

        // Ask the user which column they want to edit
        String[] options = {"Hall Name", "Capacity", "Date", "Starting Time", "Ending Time", "Hall Price"};
        String choice = (String) JOptionPane.showInputDialog(this, "Select the field to edit:", "Edit Hall",
                JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

        // Based on the choice, open the corresponding dialog
        if (choice != null) {
            switch (choice) {
                case "Hall Name":
                    String newName = JOptionPane.showInputDialog(this, "Enter new Hall Name:", hallName);
                    if (newName != null && !newName.trim().isEmpty()) {
                        model.setValueAt(newName, selectedRow, 0);
                    }
                    break;
                case "Capacity":
                    String newCapacityStr = JOptionPane.showInputDialog(this, "Enter new Capacity:", capacity);
                    if (newCapacityStr != null && !newCapacityStr.trim().isEmpty()) {
                        try {
                            model.setValueAt(Integer.parseInt(newCapacityStr), selectedRow, 1);
                        } catch (NumberFormatException e) {
                            JOptionPane.showMessageDialog(this, "Invalid input for capacity. Please enter a valid number.");
                        }
                    }
                    break;
                case "Date":
                    String newDate = JOptionPane.showInputDialog(this, "Enter new Date (YYYY/MM/DD):", date);
                    if (newDate != null && !newDate.trim().isEmpty()) {
                        model.setValueAt(newDate, selectedRow, 2);
                    }
                    break;
                case "Starting Time":
                    String newStartTime = JOptionPane.showInputDialog(this, "Enter new Starting Time:", startingTime);
                    if (newStartTime != null && !newStartTime.trim().isEmpty()) {
                        model.setValueAt(newStartTime, selectedRow, 3);
                    }
                    break;
                case "Ending Time":
                    String newEndTime = JOptionPane.showInputDialog(this, "Enter new Ending Time:", endingTime);
                    if (newEndTime != null && !newEndTime.trim().isEmpty()) {
                        model.setValueAt(newEndTime, selectedRow, 4);
                    }
                    break;
                case "Hall Price":
                    String newPriceStr = JOptionPane.showInputDialog(this, "Enter new Hall Price:", hallPrice);
                    if (newPriceStr != null && !newPriceStr.trim().isEmpty()) {
                        try {
                            model.setValueAt(Double.parseDouble(newPriceStr), selectedRow, 5);
                        } catch (NumberFormatException e) {
                            JOptionPane.showMessageDialog(this, "Invalid input for hall price. Please enter a valid number.");
                        }
                    }
                    break;
            }

            // Gather updated data
            int rowCount = model.getRowCount();
            int columnCount = model.getColumnCount();
            Object[][] updatedData = new Object[rowCount][columnCount];
            for (int i = 0; i < rowCount; i++) {
                for (int j = 0; j < columnCount; j++) {
                    updatedData[i][j] = model.getValueAt(i, j);
                }
            }

            // Save to file
            saveAllToFile(updatedData, "ViewHall.txt");
        }
    } else {
        JOptionPane.showMessageDialog(this, "Please select a hall to edit.");
    }
    }//GEN-LAST:event_editbutActionPerformed

  private String readUserName() {
    String userName = "User"; // Default name if the file is empty or not found
    try (BufferedReader br = new BufferedReader(new FileReader("USER_DATA/user_data.txt"))) {
        userName = br.readLine(); // Assuming the name is on the first line
    } catch (IOException e) {
        e.printStackTrace(); // Handle the error
    }
    return userName;
}  
    
     
    private void logoutbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutbtnActionPerformed
    // Read the user's name from the file
    String userName = readUserName();

    // Display logout message with the user's name
    JOptionPane.showMessageDialog(this, "Thank you for using the Scheduling System, " + userName + "!");
    
    // Show the Login form
    NewLoginJas loginFrame = new NewLoginJas();
    loginFrame.setVisible(true);

    // Dispose or hide the current form
    this.dispose();
    }//GEN-LAST:event_logoutbtnActionPerformed

    private void ViewFilbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ViewFilbtnActionPerformed
    // Get the selected row index from the table
    int selectedRow = HallTable.getSelectedRow();

    // Options for the user to choose from
    String[] options = {"View Details", "Filter Halls", "Sort Halls"};

    // Prompt user to select an action
    String choice = (String) JOptionPane.showInputDialog(this, "Select an action:", "View/Filter/Sort Halls",
            JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

    if ("View Details".equals(choice)) {
        if (selectedRow != -1) { // Make sure a row is selected
            // Retrieve the data from the selected row
            String hallName = HallTable.getValueAt(selectedRow, 0).toString();
            String capacity = HallTable.getValueAt(selectedRow, 1).toString();
            String date = HallTable.getValueAt(selectedRow, 2).toString();
            String startingTime = HallTable.getValueAt(selectedRow, 3).toString();
            String endingTime = HallTable.getValueAt(selectedRow, 4).toString();
            String hallPrice = HallTable.getValueAt(selectedRow, 5).toString();
            String maintenanceStartTime = HallTable.getValueAt(selectedRow, 6) != null ? HallTable.getValueAt(selectedRow, 6).toString() : "N/A"; // Updated to handle nulls
            String maintenanceEndTime = HallTable.getValueAt(selectedRow, 7) != null ? HallTable.getValueAt(selectedRow, 7).toString() : "N/A"; // Updated to handle nulls
            String remarks = HallTable.getValueAt(selectedRow, 8) != null ? HallTable.getValueAt(selectedRow, 8).toString() : "N/A"; // Updated to handle nulls

            // Display the details in a JOptionPane
            String message = String.format("Hall Name: %s\nCapacity: %s\nDate: %s\nStarting Time: %s\nEnding Time: %s\nHall Price: %s\nMaintenance Start Time: %s\nMaintenance End Time: %s\nRemarks: %s",
                    hallName, capacity, date, startingTime, endingTime, hallPrice, maintenanceStartTime, maintenanceEndTime, remarks);
            JOptionPane.showMessageDialog(this, message, "Hall Details", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Please select a hall to view.", "No Selection", JOptionPane.WARNING_MESSAGE);
        }
    } else if ("Filter Halls".equals(choice)) {
        String filterCriteria = JOptionPane.showInputDialog(this, "Enter criteria to filter by (e.g., hall name):");
        if (filterCriteria != null && !filterCriteria.trim().isEmpty()) {
            // Create a temporary model to hold filtered results
            DefaultTableModel model = (DefaultTableModel) HallTable.getModel();
            DefaultTableModel filteredModel = new DefaultTableModel();
            filteredModel.setColumnIdentifiers(new Object[]{"Hall Name", "Capacity", "Date", "Starting Time", "Ending Time", "Hall Price", "Maintenance Start Time", "Maintenance End Time", "Remarks"});

            for (int i = 0; i < model.getRowCount(); i++) { // Check each row in the original model
                String hallName = model.getValueAt(i, 0).toString().toLowerCase();
                String capacity = model.getValueAt(i, 1).toString().toLowerCase();
                String date = model.getValueAt(i, 2).toString().toLowerCase();
                String startingTime = model.getValueAt(i, 3).toString().toLowerCase();
                String endingTime = model.getValueAt(i, 4).toString().toLowerCase();
                String hallPrice = model.getValueAt(i, 5).toString().toLowerCase();
                String maintenanceStartTime = model.getValueAt(i, 6) != null ? model.getValueAt(i, 6).toString().toLowerCase() : "n/a";
                String maintenanceEndTime = model.getValueAt(i, 7) != null ? model.getValueAt(i, 7).toString().toLowerCase() : "n/a";
                String remarks = model.getValueAt(i, 8) != null ? model.getValueAt(i, 8).toString().toLowerCase() : "n/a";

                // Check if any column matches the filter criteria
                if (hallName.contains(filterCriteria.toLowerCase()) || 
                    capacity.contains(filterCriteria.toLowerCase()) ||
                    date.contains(filterCriteria.toLowerCase()) ||
                    startingTime.contains(filterCriteria.toLowerCase()) ||
                    endingTime.contains(filterCriteria.toLowerCase()) ||
                    hallPrice.contains(filterCriteria.toLowerCase()) ||
                    maintenanceStartTime.contains(filterCriteria.toLowerCase()) ||
                    maintenanceEndTime.contains(filterCriteria.toLowerCase()) ||
                    remarks.contains(filterCriteria.toLowerCase())) {
                    
                    // If a match is found, add to the filtered model
                    filteredModel.addRow(new Object[]{
                        model.getValueAt(i, 0),
                        model.getValueAt(i, 1),
                        model.getValueAt(i, 2),
                        model.getValueAt(i, 3),
                        model.getValueAt(i, 4),
                        model.getValueAt(i, 5),
                        model.getValueAt(i, 6),
                        model.getValueAt(i, 7),
                        model.getValueAt(i, 8)
                    });
                }
            }

            // Set the filtered model to the table
            HallTable.setModel(filteredModel);
        }
    } else if ("Sort Halls".equals(choice)) {
        // Get the selected column from a JComboBox or another method
        String[] columnOptions = {"Hall Name", "Capacity", "Date", "Starting Time", "Ending Time", "Hall Price", "Maintenance Start Time", "Maintenance End Time", "Remarks"};
        String selectedColumn = (String) JOptionPane.showInputDialog(this, "Select the column to sort:",
                "Sort Options", JOptionPane.QUESTION_MESSAGE, null, columnOptions, columnOptions[0]);

        // If the user cancels, exit the method
        if (selectedColumn == null) {
            return;
        }

        // Determine the column index based on the selection
        int columnIndex = Arrays.asList(columnOptions).indexOf(selectedColumn);

        // Ask the user for the sorting order
        Object[] sortOrderOptions = {"Ascending", "Descending"};
        String selectedOrder = (String) JOptionPane.showInputDialog(this, "Select the sort order:",
                "Sort Options", JOptionPane.QUESTION_MESSAGE, null, sortOrderOptions, sortOrderOptions[0]);

        // If the user cancels, exit the method
        if (selectedOrder == null) {
            return;
        }

        boolean ascending = "Ascending".equals(selectedOrder);

        // Retrieve the table model
        DefaultTableModel model = (DefaultTableModel) HallTable.getModel();
        int rowCount = model.getRowCount();

        // Create an array to hold the table data
        Object[][] data = new Object[rowCount][model.getColumnCount()];
        for (int i = 0; i < rowCount; i++) {
            for (int j = 0; j < model.getColumnCount(); j++) {
                data[i][j] = model.getValueAt(i, j);
            }
        }

        // Sort the data based on the selected column and order
        Arrays.sort(data, new Comparator<Object[]>() {
            @Override
            public int compare(Object[] row1, Object[] row2) {
                if (ascending) {
                    return row1[columnIndex].toString().compareTo(row2[columnIndex].toString());
                } else {
                    return row2[columnIndex].toString().compareTo(row1[columnIndex].toString());
                }
            }
        });

        // Clear the existing table rows
        model.setRowCount(0);

        // Add the sorted data back to the table model
        for (Object[] row : data) {
            model.addRow(row);
        }

        // Optional: Refresh the table
        HallTable.revalidate();
        HallTable.repaint();
    }

    }//GEN-LAST:event_ViewFilbtnActionPerformed

    
    
    
private void addHallToFile(String hallName, int capacity, String date, String startTime, String endTime, double price) {
    try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_PATH, true))) {  // 'true' for append mode
        String newHallData = hallName + "," + capacity + "," + date + "," + startTime + "," + endTime + "," + price;
        bw.write(newHallData);
        bw.newLine();  // Ensure each hall is written on a new line
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error adding hall to file: " + e.getMessage());
    }
}

    
private void saveAllToFile(Object[][] updatedData, String filePath) {
       try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath))) {  // Overwrite mode
        // Write the header if necessary (optional)
        bw.write("Hall Name,Capacity,Date,Starting Time,Ending Time,Hall Price");
        bw.newLine();

        // Write all hall data to the file
        for (Object[] row : updatedData) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < row.length; i++) {
                sb.append(row[i] != null ? row[i] : "");  // Handle null values
                if (i < row.length - 1) {
                    sb.append(",");  // Add commas between columns
                }
            }
            bw.write(sb.toString());
            bw.newLine();  // Ensure each hall is written on a new line
        }
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error saving data: " + e.getMessage());
    }
}
    


public static void main(String[] args) {
    java.awt.EventQueue.invokeLater(() -> new Home().setVisible(true));
}

private void loadData() {
    DefaultTableModel model = (DefaultTableModel) HallTable.getModel();
    model.setRowCount(0); // Clear current rows

    try (BufferedReader br = new BufferedReader(new FileReader(FILE_PATH))) {
        String line;
        boolean isFirstLine = true; // Flag to skip the first line

        while ((line = br.readLine()) != null) {
            // Skip the header line
            if (isFirstLine) {
                isFirstLine = false; // Set to false after the first line
                continue; // Skip this iteration
            }

            String[] hallData = line.split(","); // Split by comma

            // Check if the line has at least 6 columns
            if (hallData.length < 6) {
                System.out.println("Invalid line skipped: " + line); // Log the invalid line
                continue; // Skip this iteration if data is not valid
            }

            // Parse the data into correct types
            try {
                String hallName = hallData[0]; // Hall Name
                int capacity = Integer.parseInt(hallData[1]); // Capacity
                String date = hallData[2]; // Date
                String startingTime = hallData[3]; // Starting Time
                String endingTime = hallData[4]; // Ending Time
                double hallPrice = Double.parseDouble(hallData[5]); // Hall Price

                // Set default values for maintenance columns
                String maintenanceStartDate = hallData.length > 6 ? hallData[6] : "N/A"; // Maintenance Start Date
                String maintenanceStartTime = hallData.length > 7 ? hallData[7] : "N/A"; // Maintenance Start Time
                String maintenanceEndDate = hallData.length > 8 ? hallData[8] : "N/A"; // Maintenance End Date
                String maintenanceEndTime = hallData.length > 9 ? hallData[9] : "N/A"; // Maintenance End Time

                // Add to model
                model.addRow(new Object[]{
                    hallName,
                    capacity,
                    date,
                    startingTime,
                    endingTime,
                    hallPrice,
                    maintenanceStartDate,
                    maintenanceStartTime,
                    maintenanceEndDate,
                    maintenanceEndTime
                });
            } catch (NumberFormatException e) {
                System.out.println("Error parsing line: " + line + " - " + e.getMessage());
            }
        }
    } catch (IOException e) {
        e.printStackTrace(); // Handle exceptions
    }

    // Set column sizes (make sure this is defined)
    setColumnSizes();
}

private void setColumnSizes() {
    int columnCount = HallTable.getColumnModel().getColumnCount(); // Get the current column count

    // Set column widths based on the existing columns
    if (columnCount > 0) {
        HallTable.getColumnModel().getColumn(0).setPreferredWidth(150); // Hall Name
    }
    if (columnCount > 1) {
        HallTable.getColumnModel().getColumn(1).setPreferredWidth(55);  // Capacity
    }
    if (columnCount > 2) {
        HallTable.getColumnModel().getColumn(2).setPreferredWidth(100); // Date
    }
    if (columnCount > 3) {
        HallTable.getColumnModel().getColumn(3).setPreferredWidth(100); // Starting Time
    }
    if (columnCount > 4) {
        HallTable.getColumnModel().getColumn(4).setPreferredWidth(100); // Ending Time
    }
    if (columnCount > 5) {
        HallTable.getColumnModel().getColumn(5).setPreferredWidth(75);  // Hall Price
    }
    if (columnCount > 6) {
        HallTable.getColumnModel().getColumn(6).setPreferredWidth(120); // Maintenance Start Date
    }
    if (columnCount > 7) {
        HallTable.getColumnModel().getColumn(7).setPreferredWidth(120); // Maintenance Start Time
    }
    if (columnCount > 8) {
        HallTable.getColumnModel().getColumn(8).setPreferredWidth(120); // Maintenance End Date
    }
    if (columnCount > 9) {
        HallTable.getColumnModel().getColumn(9).setPreferredWidth(170); // Maintenance End Time
    }
}



   //C:/Users/Jason M/OneDrive/Documents/NetBeansProjects/Scheduler/src/scheduler

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable HallTable;
    private javax.swing.JPanel HomePanel;
    private javax.swing.JPanel HomepageLogo;
    private javax.swing.JToggleButton ViewFilbtn;
    private javax.swing.JToggleButton addbut;
    private javax.swing.JButton delbutton;
    private javax.swing.JToggleButton editbut;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton logoutbtn;
    private javax.swing.JButton maintenancebut;
    // End of variables declaration//GEN-END:variables
}

