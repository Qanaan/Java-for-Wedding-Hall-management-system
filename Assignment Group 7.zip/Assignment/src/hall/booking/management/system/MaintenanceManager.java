/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hall.booking.management.system;

/**
 *
 * @author hp
 */



import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class MaintenanceManager {
    private static final String FILE_NAME = "issues.txt";

    // Load issues from the file
    public List<Issue> loadIssues() {
        List<Issue> issues = new ArrayList<>();
        File file = new File(FILE_NAME);
        
        // Check if the file exists
        if (!file.exists()) {
            System.out.println("File 'issues.txt' does not exist.");
            return issues; // Return an empty list if the file is missing
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(";");
                if (data.length == 4) {
                    issues.add(new Issue(data[0], data[1], data[2], data[3]));
                } else {
                    System.out.println("Invalid line in issues.txt: " + line);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return issues;
    }

    // Save the updated list of issues to the file
    public void saveIssues(List<Issue> issues) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))) {
            for (Issue issue : issues) {
                writer.write(issue.toString() + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Find an issue by ID
    public Issue findIssueById(List<Issue> issues, String id) {
        for (Issue issue : issues) {
            if (issue.getId().equals(id)) {
                return issue;
            }
        }
        return null;
    }

    // Load staff from the staff.txt file
    public List<String> loadStaff() {
        List<String> staff = new ArrayList<>();
        File file = new File("staff.txt");

        if (!file.exists()) {
            System.out.println("File 'staff.txt' does not exist.");
            return staff; // Return an empty list if the file is missing
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                staff.add(line.trim());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return staff;
    }
}



