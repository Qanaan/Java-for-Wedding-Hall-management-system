/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hall.booking.management.system;

/**
 *
 * @author hp
 */



public class Issue {
    private String id;
    private String description;
    private String assignedScheduler;
    private String status;

    public Issue(String id, String description, String assignedScheduler, String status) {
        this.id = id;
        this.description = description;
        this.assignedScheduler = assignedScheduler;
        this.status = status;
    }

    // Getters and setters
    public String getId() {
        return id;
    }

    public String getDescription() {
        return description;
    }

    public String getAssignedScheduler() {
        return assignedScheduler;
    }

    public void setAssignedScheduler(String assignedScheduler) {
        this.assignedScheduler = assignedScheduler;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return id + ";" + description + ";" + assignedScheduler + ";" + status;
    }
}


