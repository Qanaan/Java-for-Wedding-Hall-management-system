/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hall.booking.management.system;

/**
 *
 * @author hp
 */



import hall.booking.management.system.Issue;
import hall.booking.management.system.MaintenanceManager;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class AssignSchedulerGUI extends JFrame {
    private MaintenanceManager manager;
    private List<Issue> issues;
    private List<String> staff;

    private JComboBox<String> staffComboBox;
    private JTextArea issuesTextArea;
    private JTextField issueIdField;

    public AssignSchedulerGUI() {
        setTitle("Assign Scheduler to Issue");
        setSize(500, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        manager = new MaintenanceManager();
        issues = manager.loadIssues();
        staff = manager.loadStaff();

        if (issues.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No issues found!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Panel for displaying issues
        JPanel issuesPanel = new JPanel(new BorderLayout());
        issuesTextArea = new JTextArea();
        for (Issue issue : issues) {
            issuesTextArea.append(issue.toString() + "\n");
        }
        issuesPanel.add(new JScrollPane(issuesTextArea), BorderLayout.CENTER);

        // Panel for input and assigning staff
        JPanel assignPanel = new JPanel(new GridLayout(3, 2, 10, 10));

        // Issue ID input
        assignPanel.add(new JLabel("Issue ID:"));
        issueIdField = new JTextField();
        assignPanel.add(issueIdField);

        // Staff selection from combo box
        assignPanel.add(new JLabel("Assign Staff:"));
        staffComboBox = new JComboBox<>(staff.toArray(new String[0]));
        assignPanel.add(staffComboBox);

        // Assign button
        JButton assignButton = new JButton("Assign");
        assignPanel.add(assignButton);

        // Action listener for assigning the scheduler
        assignButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String issueId = issueIdField.getText();
                Issue issue = manager.findIssueById(issues, issueId);

                if (issue != null) {
                    String selectedStaff = (String) staffComboBox.getSelectedItem();
                    issue.setAssignedScheduler(selectedStaff); // Assign staff to the issue
                    manager.saveIssues(issues);  // Save changes to file
                    refreshIssueList();  // Refresh display
                    JOptionPane.showMessageDialog(null, "Scheduler assigned successfully!");
                } else {
                    JOptionPane.showMessageDialog(null, "Issue not found!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Add components to the main window
        add(issuesPanel, BorderLayout.CENTER);
        add(assignPanel, BorderLayout.SOUTH);
    }

    // Refresh the issue list in the text area after updating
    private void refreshIssueList() {
        issuesTextArea.setText("");
        for (Issue issue : issues) {
            issuesTextArea.append(issue.toString() + "\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            AssignSchedulerGUI gui = new AssignSchedulerGUI();
            gui.setVisible(true);
        });
    }
}


