/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hall.booking.management.system;

/**
 *
 * @author hp
 */


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginGUI {
    private final UserManager userManager;

    // Constructor to initialize UserManager and build GUI
    public LoginGUI() {
        userManager = new UserManager();
        buildGUI();
    }

    // Method to build the login GUI
    private void buildGUI() {
        JFrame frame = new JFrame("Login System");  // Creating the window
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  // Close operation
        frame.setSize(400, 200);  // Setting window size
        frame.setLayout(new GridLayout(3, 2, 10, 10));  // GridLayout for simple layout

        // Adding components
        JLabel userLabel = new JLabel("Username: ");
        JTextField userField = new JTextField();  // Text field for username

        JLabel passLabel = new JLabel("Password: ");
        JPasswordField passField = new JPasswordField();  // Password field for password

        JButton loginButton = new JButton("Login");  // Login button
        JLabel statusLabel = new JLabel("");  // Label to display login status

        // Adding components to the frame
        frame.add(userLabel);
        frame.add(userField);
        frame.add(passLabel);
        frame.add(passField);
        frame.add(loginButton);
        frame.add(statusLabel);

        // ActionListener for login button
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = userField.getText();  // Get username from text field
                String password = new String(passField.getPassword());  // Get password from password field

                // Validate login
                if (userManager.validateLogin(username, password)) {
                    statusLabel.setText("Login successful!");
                    // Proceed to the next window or functionality
                } else {
                    statusLabel.setText("Login failed. Try again.");
                }
            }
        });

        frame.setVisible(true);  // Make the window visible
    }

    public static void main(String[] args) {
        // Run the Login GUI
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new LoginGUI();  // Initialize and display the login window
            }
        });
    }
}

