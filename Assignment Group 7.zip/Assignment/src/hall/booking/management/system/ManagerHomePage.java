/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hall.booking.management.system;

/**
 *
 * @author hp
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ManagerHomePage extends JFrame {
    public ManagerHomePage() {
        setTitle("Manager Home Page");
        setSize(400, 400);  // Adjusted size to accommodate extra button
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Create buttons for different functionalities
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 1));  // Adjusted grid for 5 buttons

        // Button to access Sales Dashboard
        JButton salesDashboardButton = new JButton("Sales Dashboard");
        salesDashboardButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    System.out.println("Sales Dashboard button clicked");
                    new SalesDashboardGUI().setVisible(true);  // Open Sales Dashboard GUI
                    dispose();  // Close current window
                } catch (Exception ex) {
                    ex.printStackTrace();  // Handle any errors
                }
            }
        });
        panel.add(salesDashboardButton);

        // Button to access Maintenance Dashboard
        JButton maintenanceDashboardButton = new JButton("Maintenance Dashboard");
        maintenanceDashboardButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    System.out.println("Maintenance Dashboard button clicked");
                    new MaintenanceGUI().setVisible(true);  // Open Maintenance Dashboard GUI
                    dispose();  // Close current window
                } catch (Exception ex) {
                    ex.printStackTrace();  // Handle any errors
                }
            }
        });
        panel.add(maintenanceDashboardButton);

        // Button to assign a scheduler to an issue
        JButton assignSchedulerButton = new JButton("Assign Scheduler to Issue");
        assignSchedulerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    System.out.println("Assign Scheduler button clicked");
                    new AssignSchedulerGUI().setVisible(true);  // Open Assign Scheduler GUI
                    dispose();  // Close current window
                } catch (Exception ex) {
                    ex.printStackTrace();  // Handle any errors
                }
            }
        });
        panel.add(assignSchedulerButton);

        // Button to view customer feedback
        JButton feedbackButton = new JButton("View Customer Feedback");
        feedbackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    System.out.println("View Customer Feedback button clicked");
                    new FeedbackViewerGUI().setVisible(true);  // Open Feedback Viewer GUI
                    dispose();  // Close current window
                } catch (Exception ex) {
                    ex.printStackTrace();  // Handle any errors
                }
            }
        });
        panel.add(feedbackButton);

        // Logout Button
        JButton logoutButton = new JButton("Logout");
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    System.out.println("Logout button clicked");
                    new ManagerLoginGUI().setVisible(true);  // Return to login page
                    dispose();  // Close current window
                } catch (Exception ex) {
                    ex.printStackTrace();  // Handle any errors
                }
            }
        });
        panel.add(logoutButton);

        add(panel);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ManagerHomePage());
    }
}
