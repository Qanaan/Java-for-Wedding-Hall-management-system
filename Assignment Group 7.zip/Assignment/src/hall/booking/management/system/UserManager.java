/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hall.booking.management.system;

/**
 *
 * @author hp
 */

import java.io.*;
import java.util.HashMap;

public class UserManager {
    private final String fileName = "user1.txt";
    private HashMap<String, String> userCredentials = new HashMap<>();

    public UserManager() {
        loadUsersFromFile();
    }

    // Load users from file and store in HashMap
    private void loadUsersFromFile() {
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] userData = line.split(";");
                if (userData.length >= 4) {
                    String username = userData[2]; // Username
                    String password = userData[3]; // Password
                    userCredentials.put(username, password); // Store username and password
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Validate login by checking if the username and password match
    public boolean validateLogin(String username, String password) {
        if (userCredentials.containsKey(username)) {
            return userCredentials.get(username).equals(password);
        }
        return false;
    }
}

